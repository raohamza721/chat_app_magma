package com.example.talk_shalk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
